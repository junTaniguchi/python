# -*- coding: utf-8 -*-
"""
Created on Thu Mar 16 23:08:52 2017

@author: JunTaniguchi
"""
import os, sys
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

os.chdir('/Users/JunTaniguchi/study_tensorflow/keras_project/read_place/project_rcnn')

import pyocr
import pyocr.builders
import cv2
from PIL import Image

#parser = argparse.ArgumentParser(description='tesseract ocr test')
#parser.add_argument('image', help='image path')
#args = parser.parse_args()
# 識別する言語を取得
tools = pyocr.get_available_tools()
if len(tools) == 0:
    print("No OCR tool found")
    sys.exit(1)
# tesseract使用
tool = tools[0]

# そのOCRツールで使用できる言語を確認
langs = tool.get_available_languages()
# engを指定
lang = langs[0]
# 画像を指定
img = Image.open('hrei-sign105.png')
# 文字列部分を抽出
str_list = tool.image_to_string(img,
                                lang=lang,
                                builder=pyocr.builders.WordBoxBuilder(tesseract_layout=6))
#str_list = tool.image_to_string(img,
#                                lang=lang,
#                                builder=pyocr.builders.LineBoxBuilder(tesseract_layout=6))

# 識別部分を囲む
#out = cv2.imread(img)
out = np.asarray(img)
fig, ax = plt.subplots(ncols=1, nrows=1, figsize=(6, 6))
place_list = []
for d in str_list:
    print(d.content)
    print(d.position)
    #cv2.rectangle(out, d.position[0], d.position[1], (0, 0, 255), 10)                           
    rect = mpatches.Rectangle((d.position[0][0], d.position[0][1]),
                              d.position[1][0],
                              d.position[1][1],
                              fill=False, 
                              edgecolor='red', 
                              linewidth=3)
    ax.add_patch(rect)
    ax.text(d.position[0][0] - 3,
            d.position[0][1] - 3,
            d.content,
            color='black',
            fontsize=15)
    place_list.append(d.content)
# 左上から中央まで、太さ50の赤い四角形を描く
#cv2.rectangle(img, (0, 0), (width/2, height/2), (0, 0, 255), 50)


#cv2.imshow('image',out)
ax.imshow(img)
plt.show()
place_list = [place_str.strip() for place_str in place_list if len(place_str) != 0]
print(place_list)