import os, glob
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import cv2, random

ttf_list = []
url = "/Users/JunTaniguchi/study_tensorflow/keras_project/read_place/project_rcnn"

os.chdir(url)

#フォンントのリストを作成
with open("./param/japanese_font_list.txt", "r") as japanese_ttf:
    jp_font_list = japanese_ttf.readlines()
    jp_font_list = [jp_font.strip() for jp_font in jp_font_list]

#地名のリストを作成
with open("./param/place_tokyo.txt", "r") as place_file:
    place_list = place_file.readlines()
    place_list = [place_str.strip() for place_str in place_list]

# サンプル画像を出力するフォルダ
for place_name in place_list:
    url = "./image/" + place_name
    if not os.path.exists(url):
        os.makedirs(url)

def generator():
    i = 0
    while True:
        yield i
        i+=1

def gaussianBlur_image(img_name, place_name, image_np, idx1, idx2, X, Y, font_size, x_pixel, y_pixel):
    # opencvのガウシアンフィルターを適応
    blur = cv2.GaussianBlur(image_np, (5, 5), 0)
    # 画像の中心位置
    # 今回は画像サイズの中心をとっている
    center = tuple(np.array([blur.shape[0] * 0.5, blur.shape[1] * 0.5]))
    # 画像サイズの取得(横, 縦)
    size = tuple(np.array([blur.shape[1], blur.shape[0]]))
    # 拡大比率
    scale = 1.0
    # 回転変換行列の算出
    rotation_matrix = cv2.getRotationMatrix2D(center, 0, scale)
    # アフィン変換
    blur_rot = cv2.warpAffine(blur, rotation_matrix, size, flags=cv2.INTER_CUBIC)
    affine_image = Image.fromarray(blur_rot)
    
    # 画像ファイルを保存する
    affine_image.save("./image/" + place_name + "/" + str(idx1) + img_name + "_GaussianBlur_" + str(font_size) + str(x_pixel) + str(y_pixel) + place_name + '.png', 'PNG')
    data = np.asarray(affine_image)        
    X.append(data.astype(np.float64))
    Y.append(idx2)
   
def img_make (img_name,jp_font_list, place_list, x_pixel, y_pixel, color, gen):
    X = []
    Y = []
    for idx1, jp_font in enumerate(jp_font_list):

        for font_size in range(y_pixel - 160, y_pixel - 100, + 1):
        
            for idx2, place_name in enumerate(place_list):
                # 画像のピクセルを指定
                image = Image.new('RGB', (x_pixel, y_pixel), color)
                draw = ImageDraw.Draw(image)
    
                # フォントの指定。引数は順に「フォントのパス」「フォントのサイズ」「エンコード」
                # メソッド名からも分かるようにTure Typeのフォントを指定する
                font = ImageFont.truetype(jp_font, font_size)

                # 表示文字のmarginを設定
                str_width = (font_size * len(place_name)) / 2
                x_draw_pixel = (x_pixel - str_width) / 2
                y_draw_pixel = (y_pixel - font_size) / 2
                if x_draw_pixel < 0:
                    x_draw_pixel = (x_pixel - str_width) / 2
                # 日本語の文字を入れてみる
                # 引数は順に「(文字列の左上のx座標, 文字列の左上のy座標)」「フォントの指定」「文字色」
                draw.text((x_draw_pixel, y_draw_pixel), place_name, font=font, fill='#ffffff')
                
                image_np = np.asarray(image)
                gaussianBlur_image(img_name, place_name, image_np, idx1, idx2, X, Y, font_size, x_pixel, y_pixel)
    X = np.array(X)
    Y = np.array(Y)
    np.savez("./param/npz/place_name_%s_%s.npz" % (img_name, next(gen)), x=X, y=Y)
    print("ok,", len(Y))

gen = generator()
x_pixel = 200
for y_pixel in [200]:#range(40, 46, 2):
    img_make("1", jp_font_list, place_list, x_pixel=x_pixel, y_pixel=y_pixel, color="blue", gen=gen)
    img_make("2", jp_font_list, place_list, x_pixel=x_pixel, y_pixel=y_pixel, color="green", gen=gen)
print('finish!!')